/*
 * fingerprint.h
 *
 *  Created on: Sep 29, 2019
 *      Author: hdkim
 */

#ifndef INC_FINGERPRINT_H_
#define INC_FINGERPRINT_H_


/* Includes ------------------------------------------------------------------*/
/* Private defines -----------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Exported types ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */ 
void fingerprintThread(void* argument);


#endif /* INC_FINGERPRINT_H_ */
